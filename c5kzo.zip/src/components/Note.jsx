mport React from "react";

function Note() {
  return (
    <div className="note">
      <h1> Javascipt and React.js </h1>
      <p> This was an amazing bootcamp taken up by Shourya Sir.We covered everything from scratch including Javascipt and React.js,html.</p>
      
    </div>
  );
}

export default Note;
